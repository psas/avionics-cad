The copper layers are ordered as follows from the component side to solder side:

	Top_Copper.cmp
	Inner_Copper_A.ina
	Inner_Copper_B.inb
	Bottom_Copper.sol


The solder masks are:

	Top_Solder_Mask.stc	(for Top_Copper.cmp)
	Bottom_Solder_Mask.sts	(for Bottom_Copper.sol)


The silk screen is:

	Top_Silk_Screen.plc


The Excelon drill files are:

	Drill.drd
	Drill.dri

If you have any further questions, please call me.

